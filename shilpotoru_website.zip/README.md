# শিল্পতরু

**শিল্পতরু** – বাংলার নকশিকাঠা শিল্পের জন্য একটি প্রিমিয়াম লুকের, responsive ওয়েবসাইট।

এই ওয়েবসাইটে আছে:
- Hero **slider** (মাল্টি-ইমেজ ব্যানার)
- **Gallery** with hover effects
- **Lightbox** – ছবি ক্লিক করলে বড় দেখানো হয়
- Smooth scrolling & responsive design
- Black premium theme with subtle Nokshi Katha background

## Features
- **Premium black design:** ওয়েবসাইটটি দেখতে প্রিমিয়াম ব্ল্যাক থিমের।
- **Responsive layout:** মোবাইল এবং ডেস্কটপে সুন্দর দেখায়।
- **Hero slider:** হোম পেজে স্বয়ংক্রিয়ভাবে changing images।
- **Gallery & Lightbox:** শিল্পকর্মের ছবিগুলো গ্রিড লে-আউট এবং লার্জ ভিউ।
- **Easy to customize:** ছবি ও টেক্সট সহজেই পরিবর্তন করা যায়।

## Usage
1. Repository ডাউনলোড / Clone করো:
```bash
git clone https://github.com/USERNAME/shilpotoru.git
```
2. ফোল্ডার ওপেন করে `index.html` ব্রাউজারে ওপেন করো।
3. নিজের ছবি ও কন্টেন্ট আপডেট করতে চাইলে `index.html` ফাইলে পরিবর্তন করো।

## Live Demo
[https://USERNAME.github.io/shilpotoru/](https://USERNAME.github.io/shilpotoru/)

## License
© 2025 **শিল্পতরু**. সর্বস্বত্ব সংরক্ষিত।
